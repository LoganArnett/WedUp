'use strict'
angular.module('mychat')
   .controller('LoginController', function($scope,$rootScope,$state, $ionicLoading,$ionicModal,$ionicPopup,$timeout,AuthService,Chatservice) {
    $scope.users = {
      email:  "",
      password: "",
      confirm: ""
    }
    $scope.loginuser = {
      email: "",
      password: "",
      submitEmail: ""
    }
    if(localStorage.getItem("TokenId")){
      $state.go('tabs.chat');
    }

    $ionicModal.fromTemplateUrl('templates/signup.html',{
      scope: $scope
    }).then(function (modal){
      $scope.signupModal = modal;
    });
    $scope.EmailLogin = function() {
      if($scope.loginuser.email == '' || $scope.loginuser.password == '') {

        if($scope.loginuser.email == '' && $scope.loginuser.password == '')
        {
          var alertPopup = $ionicPopup.alert({
            title: 'Login',
            template: 'Please input email and password'
          });
        } else {
          if ($scope.loginuser.email == '') {
            var alertPopup = $ionicPopup.alert({
              title: 'Login',
              template: 'Please input email'
            });
          } else if ($scope.loginuser.password == '') {
            var alertPopup = $ionicPopup.alert({
              title: 'Login',
              template: 'Please input password'
            });
          }
        }
      } else {

        AuthService.Emaillogin($scope.loginuser.email, $scope.loginuser.password).then(function (loginResult) {
          if (loginResult.loggedIn == true) {

            var Ref = firebase.database().ref('chatroom1/messages');
            Ref.once('value').then(function(data){
              if (data) {
                var val = data.val();
                //val = JSON.stringify(val);
                  angular.forEach(val, function(val, key) {
                    /*
                    if(val.id == loginResult.id)
                      Chatservice.displayMessage(key, val.name, val.text, val.photoUrl, val.imageUrl,'send');
                    else
                      Chatservice.displayMessage(key, val.name, val.text, val.photoUrl, val.imageUrl,'receive');
                    */
                    Chatservice.displayMessage(key, val.name, val.text, val.photoUrl, val.imageUrl,'receive');
                  });
              }
            });
            $state.go('tabs.chat');
          }
        });
      }

    }

    $scope.Signup = function() {
      /* User Sign Up */
      if($scope.users.email == '' || $scope.users.password == '') {

        if($scope.users.email == '' && $scope.users.password == '')
        {
          var alertPopup = $ionicPopup.alert({
            title: 'Signup',
            template: 'Please input email and password'
          });
        } else {
          if ($scope.users.email == '') {
            var alertPopup = $ionicPopup.alert({
              title: 'Signup',
              template: 'Please input email'
            });
          } else if ($scope.users.password == '') {
            var alertPopup = $ionicPopup.alert({
              title: 'Signup',
              template: 'Please input password'
            });
          }
        }
      } else {
        if($scope.users.password.length < 8)
        {
          var alertPopup = $ionicPopup.alert({
            title: 'Password Alert',
            template: "Password is not short. At least password should be 8 characters"
          });

        } else {
          if ($scope.users.password == $scope.users.confirm) {
            AuthService.EmailSignup($scope.users.email, $scope.users.password);

          } else {
            var alertPopup = $ionicPopup.alert({
              title: 'Signup',
              template: "Password and Confirm password doesn't match"
            });
          }
        }
      }


    }
    $scope.Keysubmit = function() {

      AuthService.SendResetEmail($scope.loginuser.submitEmail).then(function(result) {
        if(result.isSendResetEmail) {
          $scope.forgetModal.hide();
        }
      });
    }

    $scope.closeSignup = function () {
      $scope.signupModal.hide();
    }
    $scope.SignupScreen = function() {
      $scope.signupModal.show();
    }

    $ionicModal.fromTemplateUrl('templates/forgetpage.html',{
      scope: $scope
    }).then(function (modal){
      $scope.forgetModal = modal;
    });
    $scope.closeForget = function () {
      $scope.forgetModal.hide();
    }
    $scope.ForgetPwdPage = function() {
      $scope.forgetModal.show();
    }
    $scope.GoogleSignin = function () {
      AuthService.SigninwithGoogle().then(function(result){
        if(result.googleIn == true) {
          $state.go('tabs.chat');
        }
      });
    }
    $scope.FacebookSignin = function () {
      AuthService.SigninwithFacebook().then(function(result){
        if(result.facebookIn == true) {
          $state.go('tabs.chat');
        }
      });

    }

  });
