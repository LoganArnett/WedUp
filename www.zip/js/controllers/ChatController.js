'use strict'
angular.module('mychat')
  .controller('ChatController', function($rootScope,$scope,$state,$timeout,$ionicModal,$ionicScrollDelegate, AuthService,Chatservice,ProfileService,photoservice) {

    $scope.user = {
      username:'',
      message:''
    }
    $scope.profile = {
      username: '',
      role: '',
      describe: '',
      photoUrl: 'images/profileavatar.jpg',
      isChoosePhoto: false
    }
    $scope.flag = false;
    loadingMessage();
    $scope.Logout = function() {
      AuthService.Logout().then(function(Result){
        if(Result.loggingout == true) {
          $state.go('login');
          $(".messageReceive-container").remove();
        }
      });
    }
    $ionicModal.fromTemplateUrl('templates/profilepage.html',{
      scope: $scope
    }).then(function (modal){
      $scope.profilepage = modal;
    });
    $scope.closeProfile = function () {
      $scope.profilepage.hide();
    }
    $scope.ProfilePage = function() {
      ProfileService.GetuserInfo().then(function(result) {
         $scope.profile.username = result.name;
         $scope.profile.role = result.role;
         $scope.profile.describe = result.describe;
         if(result.photoUrl)
          $scope.profile.isChoosePhoto = true;
         else
           $scope.profile.isChoosePhoto = false;

         if(result.photoUrl != '')
          $scope.profile.photoUrl = result.photoUrl;
         else
           $scope.profile.photoUrl = "images/profileavatar.jpg";
      });
      $scope.profilepage.show();
    }

    $scope.SendMessage = function(){
      var user = firebase.auth().currentUser;
      var profileRef = firebase.database().ref('profile/' + user.uid);
       profileRef.once('value').then(function (data) {

          if (data) {
            var val = data.val();
            if (val != null) {
              angular.forEach(val, function (val) {
                Chatservice.SendMessage($scope.user.message, val.name, val.photoUrl).then(function(result){
                  if(result.isSend) {
                    $scope.user.message = "";
                  }
                })
              });
            } else {
              Chatservice.SendMessage($scope.user.message, '','').then(function(result){
                if(result.isSend) {
                  $scope.user.message = "";
                }
              })

            }
          }
       }).catch(function (error) {
          $scope.user.message = "";
           var alertPopup = $ionicPopup.alert({
             title: 'Message',
             template: error
           });
       });
    }
    $scope.SendImage = function() {
      photoservice.GetfromGalleryWithFile().then(function(result){
         if(result.isChoosePhotoWithFile) {
           /* Get profile user name and photo */
           var user = firebase.auth().currentUser;
           var profileRef = firebase.database().ref('profile/' + user.uid);
           profileRef.once('value').then(function (data) {

             if (data) {
               var val = data.val();
               if (val != null) {
                 angular.forEach(val, function (val) {

                   Chatservice.SendImage(result.photoUrl,val.photoUrl, val.name).then(function(result){
                     if(result.isSend) {

                     }
                   })
                 });
               }             }
           }).catch(function (error) {
             $scope.user.message = "";
             var alertPopup = $ionicPopup.alert({
               title: 'Message',
               template: error
             });
           });

         }
      });
      //var file = null;
      //$('#file_upload').click();
      //$('#file_upload').on('change',function(e){
      //  file = e.target.files[0];
      //  Chatservice.SendImage(file);
      //});
    }
    function loadingMessage() {
      var Ref = firebase.database().ref('chatroom1/messages');
      Ref.off();
      var setMessage = function (data) {
        if (data) {
          var user = firebase.auth().currentUser;
          var val = data.val();
          /*
          if(val.id == user.uid)
            Chatservice.displayMessage(data.key, val.name, val.text, val.photoUrl, val.imageUrl,'send');
          else
            Chatservice.displayMessage(data.key, val.name, val.text, val.photoUrl, val.imageUrl,'receive');
           */
          Chatservice.displayMessage(data.key, val.name, val.text, val.photoUrl, val.imageUrl,'receive');
        }
      }.bind();
      Ref.limitToLast(12).on('child_added', setMessage);
      Ref.limitToLast(12).on('child_changed', setMessage);
    }

    $scope.ProfileSave = function() {
      //alert($scope.profile.username);
      ProfileService.ProfileSave($scope.profile).then(function(result){
        if(result.profileSaved) {
            $scope.profilepage.hide();
        }
      });
    }

    /*----------- Profile photo take -----------*/
    $scope.takePhoto = function () {
      photoservice.takePhoto().then(function(result){

        if(result.photoUrl != '')
          $scope.profile.photoUrl = result.photoUrl;
        else
          $scope.profile.photoUrl = "images/profileavatar.jpg";

        $scope.profile.isChoosePhoto = result.isChoosePhoto;
      });
    }
    $scope.choosePhoto = function() {
      photoservice.GetfromGallery().then(function(result){
        if(result.photoUrl != '')
          $scope.profile.photoUrl = result.photoUrl;
        else
          $scope.profile.photoUrl = "images/profileavatar.jpg";

        $scope.profile.isChoosePhoto = result.isChoosePhoto;
      });
    }

  })
