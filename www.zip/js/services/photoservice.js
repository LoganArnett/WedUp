angular.module('mychat.photoservice',[])
  .factory('photoservice', function($ionicPopup, $cordovaCamera, $q) {
    var isChoosePhoto = false;
    var isChoosePhotoWithFile = false;
    var photoUrl = '';
    return{
      takePhoto: function(){
        var deferred = $q.defer();
        var options = {
          quality: 75,
          destinationType: Camera.DestinationType.DATA_URL,
          sourceType: Camera.PictureSourceType.CAMERA,
          allowEdit: true,
          encodingType: Camera.EncodingType.JPEG,
          targetWidth: 120,
          targetHeight: 120,
          popoverOptions: CameraPopoverOptions,
          saveToPhotoAlbum: true,
          correctOrientation: true
        };

        $cordovaCamera.getPicture(options).then(function (sourcePath) {
          window.resolveLocalFileSystemURL(sourcePath, copyFile, fail);
          function onCopySuccess(entry) {
            isChoosePhoto = true;

            deferred.resolve({
              "isChoosePhoto": isChoosePhoto,
              "photoUrl": entry.nativeURL
            });
          }

          function fail(error) {
            isChoosePhoto = false;

            deferred.resolve({
              "isChoosePhoto": isChoosePhoto,
              "photoUrl": ''
            });
            var alertPopup = $ionicPopup.alert({
              title: 'Take photo',
              template: error
            });
          }

          function copyFile(fileEntry) {
            var text = "";
            var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            for (var i = 0; i < 5; i++) {
              text += possible.charAt(Math.floor(Math.random() * possible.length));
            }
            var name = fileEntry.fullPath.substr(fileEntry.fullPath.lastIndexOf('/') + 1);
            var newName = text + name;
            window.resolveLocalFileSystemURL(cordova.file.dataDirectory, function (fileSystem2) {
              fileEntry.copyTo(
                fileSystem2,
                newName,
                onCopySuccess,
                fail
              )
            }, fail);
          }
        });

        return deferred.promise;
      },
      GetfromGallery: function() {
        var deferred = $q.defer();
        var options = {
          quality: 75,
          destinationType: Camera.DestinationType.DATA_URL,
          sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
          allowEdit: true,
          encodingType: Camera.EncodingType.JPEG,
          mediaType: Camera.MediaType.PICTURE,
          targetWidth: 120,
          targetHeight: 120,
          popoverOptions: CameraPopoverOptions,
          saveToPhotoAlbum: false,
          correctOrientation: true
        };

       $cordovaCamera.getPicture(options).then(function (sourcePath) {
          photoUrl = "data:image/jpeg;base64," + sourcePath;
          isChoosePhoto = true;

          deferred.resolve({
            "isChoosePhoto": isChoosePhoto,
            "photoUrl": photoUrl
          });

        }, function (err) {
          isChoosePhoto = false;
          deferred.resolve({
            "isChoosePhoto": isChoosePhoto,
            "photoUrl": ''
          });
          var alertPopup = $ionicPopup.alert({
            title: 'Choose photo',
            template: err
          });
        });

        return deferred.promise;

      },
      GetfromGalleryWithFile: function() {
        var deferred = $q.defer();
        var options = {
          quality: 75,
          destinationType: Camera.DestinationType.FILE_URI,
          sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
          allowEdit: true,
          encodingType: Camera.EncodingType.JPEG,
          mediaType: Camera.MediaType.PICTURE,
          targetWidth: 120,
          targetHeight: 120,
          popoverOptions: CameraPopoverOptions,
          saveToPhotoAlbum: false,
          correctOrientation: true
        };

        $cordovaCamera.getPicture(options).then(function (sourcePath) {
          isChoosePhotoWithFile = true;

          deferred.resolve({
            "isChoosePhotoWithFile": isChoosePhotoWithFile,
            "photoUrl": sourcePath
          });

        }, function (err) {
          isChoosePhotoWithFile = false;
          deferred.resolve({
            "isChoosePhotoWithFile": isChoosePhoto,
            "photoUrl": ''
          });
          var alertPopup = $ionicPopup.alert({
            title: 'Choose photo',
            template: err
          });
        });

        return deferred.promise;

      }

    }


  });
